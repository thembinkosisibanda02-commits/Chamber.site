import http from 'node:http';
import crypto from 'node:crypto';
import express from 'express';
import { WebSocketServer, WebSocket } from 'ws';

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true });
const sessions = new Map();
const PORT = Number(process.env.PORT || 3000);
const TTL = Number(process.env.SESSION_TTL_MS || 3600000);
const API = 'https://api.derivws.com';

app.use(express.json({ limit: '32kb' }));
app.use(express.static(new URL('./public', import.meta.url).pathname));

function cookieSession(req) {
  const m = /(?:^|; )cs_session=([^;]+)/.exec(req.headers.cookie || '');
  return m ? decodeURIComponent(m[1]) : null;
}
function setSessionCookie(res, id) {
  res.setHeader('Set-Cookie', `cs_session=${encodeURIComponent(id)}; Path=/; HttpOnly; SameSite=Lax; Secure`);
}
function getSession(req) {
  const id = cookieSession(req);
  const s = id && sessions.get(id);
  if (!s || s.expires < Date.now()) { if (id) sessions.delete(id); return null; }
  s.expires = Date.now() + TTL;
  return s;
}
async function getOtp({ token, appId, accountId }) {
  const headers = { Authorization: `Bearer ${token}` };
  headers['Deriv-App-ID'] = appId;
  const r = await fetch(`${API}/trading/v1/options/accounts/${encodeURIComponent(accountId)}/otp`, { method: 'POST', headers });
  const body = await r.json().catch(() => ({}));
  if (!r.ok || !body?.data?.url) {
    const msg = body?.errors?.[0]?.message || `Deriv returned HTTP ${r.status}`;
    throw new Error(msg);
  }
  return body.data.url;
}

app.post('/api/connect', async (req, res) => {
  try {
    const { token, appId, accountId, environment } = req.body || {};
    if (!token || !appId || !accountId) return res.status(400).json({ ok:false, error:'PAT, Deriv App ID, and account ID are required.' });
    const url = await getOtp({ token: String(token).trim(), appId: appId ? String(appId).trim() : '', accountId: String(accountId).trim() });
    const expected = environment === 'real' ? '/ws/real?' : '/ws/demo?';
    if (!url.includes(expected)) {
      return res.status(400).json({ ok:false, error:`The selected account does not match the ${environment === 'real' ? 'real' : 'demo'} environment.` });
    }
    const id = crypto.randomUUID();
    sessions.set(id, {
      token: String(token).trim(),
      appId: appId ? String(appId).trim() : '',
      accountId: String(accountId).trim(),
      environment: environment === 'real' ? 'real' : 'demo',
      expires: Date.now() + TTL
    });
    setSessionCookie(res, id);
    // Do not return the token or the OTP URL to the browser.
    res.json({ ok:true, accountId:String(accountId).trim(), environment: environment === 'real' ? 'real' : 'demo' });
  } catch (e) {
    res.status(400).json({ ok:false, error:e.message || 'Connection failed.' });
  }
});

app.post('/api/disconnect', (req, res) => {
  const id = cookieSession(req); if (id) sessions.delete(id);
  res.setHeader('Set-Cookie', 'cs_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax; Secure');
  res.json({ ok:true });
});

app.get('/api/session', (req, res) => {
  const s = getSession(req);
  res.json(s ? { connected:true, accountId:s.accountId, environment:s.environment } : { connected:false });
});

server.on('upgrade', (req, socket, head) => {
  if (req.url !== '/api/deriv-ws') { socket.destroy(); return; }
  wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws, req));
});

wss.on('connection', async (client, req) => {
  const session = getSession(req);
  if (!session) { client.close(1008, 'Not connected'); return; }
  let upstream;
  try {
    const url = await getOtp(session);
    upstream = new WebSocket(url);
    upstream.on('open', () => client.send(JSON.stringify({ type:'proxy_status', status:'connected', environment:session.environment, accountId:session.accountId })));
    upstream.on('message', data => { if (client.readyState === WebSocket.OPEN) client.send(data.toString()); });
    upstream.on('close', () => { if (client.readyState === WebSocket.OPEN) client.close(1000, 'Deriv connection closed'); });
    upstream.on('error', err => { if (client.readyState === WebSocket.OPEN) client.send(JSON.stringify({ error: err.message })); });
    client.on('message', data => {
      if (upstream?.readyState === WebSocket.OPEN) upstream.send(data);
    });
    client.on('close', () => upstream?.close());
  } catch (e) {
    client.close(1011, e.message || 'Unable to authenticate');
  }
});

setInterval(() => {
  const now = Date.now();
  for (const [id, s] of sessions) if (s.expires < now) sessions.delete(id);
}, 10 * 60 * 1000).unref();

server.listen(PORT, () => console.log(`ChamberSite running on http://localhost:${PORT}`));
